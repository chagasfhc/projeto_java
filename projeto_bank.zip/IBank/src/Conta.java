import java.util.Scanner;

public abstract class Conta extends Interface {
	private static int numero;
	private static double cpf;
	private static String agencia;
	private static String dono;
	private static double saldo;



	public static int getNumero() {
		return numero;
	}

	public static void setNumero(int numero) {
		Conta.numero = numero;
	}

	public static double getCpf() {
		return cpf;
	}

	public static void setCpf(double cpf) {
		Conta.cpf = cpf;
	}

	public static String getAgencia() {
		return agencia;
	}

	public static void setAgencia(String agencia) {
		Conta.agencia = agencia;
	}

	public static String getDono() {
		return dono;
	}

	public static void setDono(String dono) {
		Conta.dono = dono;
	}

	public static double getSaldo() {
		return saldo;
	}

	public static void setSaldo(double saldo) {
		Conta.saldo = saldo;
	}

	public static Object sacar(double valor) {
		if (saldo >= valor) {
			saldo = saldo - valor;
			
			anima�ao(1);

		} else {
			System.out.println("saldo insuficiente");
		}
		return null;
	}

	public static Object depositar(double valor) {
		
		return null;
	}

	public abstract void exibirSaldo();

	public static Object transferir(double valor, Conta contaDestino) {
		sacar(valor);
		return contaDestino.depositar(valor);

	}

	public void Cadrasto() {
		boolean confi = false;
		boolean confi2 = false;

		if (getDono() == null && getCpf() == 0) {
			confi = true;
		}
		if (getAgencia() == null && getNumero() == 0) {
			confi2 = true;
		}
		if (confi && confi2) {
			 cadrastando();
		}
		else { menu();}

	}

	private void cadrastando() {
		cadrastandoConta();
		
		try (Scanner ler = new Scanner(System.in)) {
			System.out.print("digite seu nome: ");
			String nome = ler.nextLine();

			System.out.print("digite sua agencia: ");
			String agencia = ler.nextLine();

			System.out.print("digite seu cpf: ");
			double cpf = ler.nextDouble();

			setDono(nome);
			setAgencia(agencia);
			setCpf(cpf);

			anima�ao(6);
			cotinuidade();
			 menu();
		}
	}

	public static Object decisao(int decisao) {
		try (Scanner ler = new Scanner(System.in)) {
			if (decisao == 1) {
				System.out.println("digite o valor: ");
				double valor = ler.nextDouble();
				return sacar(valor);
			}

			else if (decisao == 2) {
				System.out.println("digite o valor: ");
				double valor = ler.nextDouble();
				return depositar(valor);
			}

			else if (decisao == 3) {
				System.out.println("digite o valor: ");
				double valor = ler.nextDouble();

				System.out.println("conta destino: ");
				ContaInvestimento contaDestino = new ContaInvestimento();

				return transferir(valor, contaDestino);
			}

			else if (decisao == 4) {
				System.out.println("saldo dis:" + getSaldo());
			}

			else if (decisao == 5) {
				System.out.println("creditos:" + "Carlos," + "Jose Alisson e " + "tarcisio");
			}
		}

		return "nao identificado";
	}
}
