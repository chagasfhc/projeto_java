public class ContaInvestimento extends Conta {
	private final double RENDIMENTO = 2;

	public double getRendimento() {
		return RENDIMENTO;
	}

	

	@Override
	public void exibirSaldo() {
		System.out.println("Conta investimento" + this.getSaldo());

	}

}
