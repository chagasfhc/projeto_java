public class ContaCorrente extends Conta {
	private final double DESCONTO = 5;

	public double getDesconto() {
		return DESCONTO;
	}

	@Override
	public void exibirSaldo() {
		// TODO Auto-generated method stub
		System.out.println("Conta corrente" + this.getSaldo());
	}
	
	
	
}
