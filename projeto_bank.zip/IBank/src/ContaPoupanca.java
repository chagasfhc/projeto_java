public class ContaPoupanca extends Conta {
	private final double BONUS = 10;

	public double getBonus() {
		return BONUS;
	}

	

	@Override
	public void exibirSaldo() {
		System.out.println("Conta poupan�a. Seu saldo � " + this.getSaldo());

	}

}
