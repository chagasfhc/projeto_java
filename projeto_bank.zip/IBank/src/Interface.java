import java.util.Scanner;

public class Interface {
	public void quebralinha() {
		for (int i = 0; i < 50000; i++) {
			System.out.println();
		}

	}

	public void cadrastandoConta() {
		System.out.println("     Cadrasto de Conta      ");
		System.out.println(".............................");

	}

	public void menu() {
		Scanner ler = new Scanner(System.in);
		System.out.println("          MENU Ibank           ");
		System.out.println("//---------------------------//");
		System.out.println("    1 para sacar............");
		System.out.println("    2 para depositar........");
		System.out.println("    3 para trasferir........");
		System.out.println("    4 para exibir saldo.....");
		System.out.println("    5 para exibir creditos..");
		System.out.println("    6 Cadrastando Conta.....");
		System.out.println("//---------------------------//");
		System.out.print("res: ");
		int c = ler.nextInt();
		Conta.decisao(c);
		// desisao = 0;
		ler.close();
	}

	public static Object anima�ao(int a) {
		switch (a) {
		case (1):
			System.out.println("//---------------------//");
			System.out.println("      Valor Sacado       ");
			System.out.println("//---------------------//");
			System.out.println("saldo dis: " + Conta.getSaldo());
			break;
		case (2):
			System.out.println("//---------------------//");
			System.out.println("     Valor depositado    ");
			System.out.println("//---------------------//");
			System.out.println("saldo dis: " + Conta.getSaldo());
			break;
		case (3):
			System.out.println("//---------------------//");
			System.out.println("    valor trasferindo    ");
			System.out.println("//---------------------//");
			System.out.println("saldo dis: " + Conta.getSaldo());
			break;
		case (4):
			System.out.println("//---------------------//");
			System.out.println("     Exibindo saldo      ");
			System.out.println("//---------------------//");
			System.out.println("saldo dis: " + Conta.getSaldo());
			break;
		case (5):
			System.out.println("//---------------------//");
			System.out.println("    Exibindo creditos    ");
			System.out.println("//---------------------//");
			break;
		case (6):
			System.out.println("//---------------------//");
			System.out.println("    Cadrastando Conta    ");
			System.out.println("//---------------------//");
			break;

		default:
			break;
		}
		return null;
	}

	public void cotinuidade() {
		Scanner ler = new Scanner(System.in);

		System.out.println("proseguir s/n");
		System.out.println("res: ");
		String res = ler.nextLine();

		if (res != "0101") {
			quebralinha();
		} else {
			quebralinha();
		}
		ler.close();

	}
}
