
public class Principal extends Conta {
	public static void main(String[] args) {

		ContaCorrente cc = new ContaCorrente();
		ContaPoupanca cp = new ContaPoupanca();
		ContaInvestimento ci = new ContaInvestimento();
		// Interface inter = new Interface();

		Conta.setSaldo(1000);

		do{cc.Cadrasto(); ;}while(true);

	}

	@Override
	public void exibirSaldo() {
	}
}
